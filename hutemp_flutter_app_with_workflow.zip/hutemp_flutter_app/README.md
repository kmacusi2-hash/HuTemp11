
HuTemp - Flutter App (Scaffold)
================================

This project is a minimal Flutter scaffold for the HuTemp app you requested.
It implements:
- Minimalist UI with light-blue theme
- Wi-Fi (HTTP) integration: read JSON from ESP32 local endpoint (e.g. http://192.168.4.1/data)
- Stores last 4 readings (every 4 hours logic handled when fetching)
- Bar graph for last 4 readings (fl_chart) with gradient coloring: highest=red, lowest=blue, normal=green
- In-app notifications and connection checks
- Creator logo included (assets/logo.png)

How to run (Android/iOS):
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. In project folder, run:
   flutter pub get
   flutter run   # to run on connected device or emulator

Building APK / IPA:
- Android: flutter build apk --release
- iOS: flutter build ios (requires macOS & Xcode, and Apple Developer account for release)

Notes:
- The app uses an HTTP GET to fetch JSON from your ESP32. The JSON should be:
  { "temperature": 24.5, "humidity": 60 }
- The app saves readings to SharedPreferences and will add a new record only if at least 4 hours passed since the last stored record.
- For push notifications (system-level), integrate firebase_messaging or flutter_local_notifications; this scaffold uses in-app dialogs & snackbars for warnings.


## Automated APK builds via GitHub Actions

1. Create a new GitHub repository and push this project to `main`.
2. Go to the **Actions** tab and run the **Build HuTemp APK** workflow (or trigger it by pushing to main).
3. After the workflow completes, download the artifacts `HuTemp-debug-apk` or `HuTemp-release-apk` from the run page.
