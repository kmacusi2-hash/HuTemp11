import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

void main() {
  runApp(HuTempApp());
}

class HuTempApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HuTemp',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFE1F5FE),
        fontFamily: 'Helvetica',
      ),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Reading {
  final double temp;
  final double hum;
  final DateTime time;
  Reading({required this.temp, required this.hum, required this.time});
  Map<String, dynamic> toJson() => {'temp': temp, 'hum': hum, 'time': time.toIso8601String()};
  static Reading fromJson(Map<String, dynamic> j) => Reading(
    temp: (j['temp'] as num).toDouble(),
    hum: (j['hum'] as num).toDouble(),
    time: DateTime.parse(j['time'] as String),
  );
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool useBlynk = false;
  String blynkToken = '';
  String vPinTemp = '0';
  String vPinHum = '1';
  String espUrl = 'http://192.168.4.1/data';
  double? temperature;
  double? humidity;
  bool loading = false;
  List<Reading> history = [];
  Timer? timer;
  late SharedPreferences prefs;
  final DateFormat timeFormat = DateFormat.Hm();

  @override
  void initState() {
    super.initState();
    initPrefs();
    timer = Timer.periodic(Duration(seconds: 10), (_) => fetchData()); // poll every 10s for demo
    Connectivity().onConnectivityChanged.listen((status) {
      if (status == ConnectivityResult.none) {
        showSnackbar('No network connection');
      }
    });
  }

  Future initPrefs() async {
    prefs = await SharedPreferences.getInstance();
    loadHistory();
  }

  void loadHistory() {
    final raw = prefs.getStringList('history') ?? [];
    history = raw.map((s) => Reading.fromJson(json.decode(s))).toList();
    setState(() {});
  }

  Future saveHistory() async {
    final list = history.map((r) => json.encode(r.toJson())).toList();
    await prefs.setStringList('history', list);
  }

  Future fetchData() async {
    setState(() => loading = true);
    try {
      // Check connectivity first
      var conn = await Connectivity().checkConnectivity();
      if (conn == ConnectivityResult.none) {
        showDialog(context: context, builder: (_) => AlertDialog(title: Text('No Connection'), content: Text('Please connect to Wi-Fi to reach the ESP32.'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
        return;
      }

      if (useBlynk) {
        if (blynkToken.isEmpty) return;
        final tRes = await http.get(Uri.parse('https://blynk.cloud/external/api/get?token=$blynkToken&v$vPinTemp'));
        final hRes = await http.get(Uri.parse('https://blynk.cloud/external/api/get?token=$blynkToken&v$vPinHum'));
        double t = double.tryParse(tRes.body.trim()) ?? double.nan;
        double h = double.tryParse(hRes.body.trim()) ?? double.nan;
        if (t.isNaN || h.isNaN) throw Exception('Invalid Blynk response');
        temperature = t; humidity = h;
      } else {
        final res = await http.get(Uri.parse(espUrl)).timeout(Duration(seconds: 5));
        final obj = json.decode(res.body);
        temperature = (obj['temperature'] as num).toDouble();
        humidity = (obj['humidity'] as num).toDouble();
      }

      // store every 4 hours logic: if history empty, push; else push if >=4h since last stored
      if (history.isEmpty || DateTime.now().difference(history.last.time) >= Duration(hours: 4)) {
        history.add(Reading(temp: temperature!, hum: humidity!, time: DateTime.now()));
        if (history.length > 4) history.removeAt(0);
        await saveHistory();
      }

      checkWarnings();
    } catch (e) {
      showSnackbar('Failed to fetch data. Check ESP32 or Blynk settings.');
    } finally {
      setState(() => loading = false);
    }
  }

  void checkWarnings() {
    if (temperature == null || humidity == null) return;
    if (temperature! > 35) {
      showAlert('Too Hot', 'Temperature is high. Use fan or AC, stay hydrated.');
    } else if (temperature! < 20) {
      showAlert('Too Cold', 'Temperature is low. Keep warm.');
    } else if (humidity! > 70) {
      showAlert('Too Humid', 'Ventilate the room or use a dehumidifier.');
    } else if (humidity! < 30) {
      showAlert('Too Dry', 'Use a humidifier or add moisture.');
    }
  }

  void showSnackbar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: Duration(seconds: 3)));
  }

  void showAlert(String title, String body) {
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
  }

  Color gradientColorForTemp(double value, double min, double max) {
    // map value between min(blue) -> normal(green) -> max(red)
    double mid = (min + max) / 2;
    if (value <= mid) {
      double t = (value - min) / (mid - min + 0.0001);
      return Color.lerp(Colors.blue, Colors.green, t)!;
    } else {
      double t = (value - mid) / (max - mid + 0.0001);
      return Color.lerp(Colors.green, Colors.red, t)!;
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget buildChart() {
    if (history.isEmpty) {
      return Center(child: Text('No historical data', style: TextStyle(color: Colors.blueGrey)));
    }
    double minT = history.map((r) => r.temp).reduce((a,b)=> a<b?a:b);
    double maxT = history.map((r) => r.temp).reduce((a,b)=> a>b?a:b);
    List<BarChartGroupData> groups = [];
    for (int i=0;i<history.length;i++) {
      final r = history[i];
      final color = gradientColorForTemp(r.temp, minT, maxT);
      groups.add(BarChartGroupData(x: i, barRods: [BarChartRodData(toY: r.temp, color: color, width: 18)], showingTooltipIndicators: [0]));
    }
    return BarChart(BarChartData(
      alignment: BarChartAlignment.spaceAround,
      maxY: (maxT + 5),
      barTouchData: BarTouchData(enabled: false),
      titlesData: FlTitlesData(
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28)),
        bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (val,meta){
          int idx = val.toInt();
          if (idx<0||idx>=history.length) return Text('');
          return Text(timeFormat.format(history[idx].time), style: TextStyle(fontSize:12));
        }))
      ),
      borderData: FlBorderData(show: false),
      barGroups: groups,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final Color primary = Color(0xFFB3E5FC);
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Image.asset('assets/logo.png', height: 32),
          SizedBox(width:8),
          Text('HuTemp', style: TextStyle(fontWeight: FontWeight.w600))
        ]),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black87,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 2,
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Temperature', style: TextStyle(color: Colors.blueGrey)),
                      SizedBox(height:6),
                      Text(temperature==null? '--' : '${temperature!.toStringAsFixed(1)} °C', style: TextStyle(fontSize:24, fontWeight: FontWeight.bold, color: temperature==null?Colors.black87: gradientColorForTemp(temperature!, (history.isEmpty?20:history.map((r)=>r.temp).reduce((a,b)=> a<b?a:b)), (history.isEmpty?35:history.map((r)=>r.temp).reduce((a,b)=> a>b?a:b)) ))),
                      SizedBox(height:6),
                      Text('Humidity: ${humidity==null? "--" : humidity!.toStringAsFixed(0) } %', style: TextStyle(color: Colors.blueGrey))
                    ]),
                    ElevatedButton(onPressed: fetchData, child: loading? SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)): Text('Refresh'))
                  ],
                ),
              ),
            ),
            SizedBox(height:12),
            Text('Past Records (every 4 hrs)', style: TextStyle(color: Colors.blueGrey)),
            SizedBox(height:8),
            Expanded(child: Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: buildChart())),
            SizedBox(height:12),
            Row(children: [
              Expanded(child: Text('Mode:')),
              Switch(value: useBlynk, onChanged: (v){ setState(()=>useBlynk=v); })
            ]),
            if (useBlynk) ...[
              TextField(decoration: InputDecoration(labelText: 'Blynk Token'), onChanged: (v)=>blynkToken=v),
              Row(children: [Flexible(child: TextField(decoration: InputDecoration(labelText: 'Temp vPin'), onChanged: (v)=>vPinTemp=v)), SizedBox(width:8), Flexible(child: TextField(decoration: InputDecoration(labelText: 'Hum vPin'), onChanged: (v)=>vPinHum=v))])
            ] else ...[
              TextField(decoration: InputDecoration(labelText: 'ESP URL (http://ip/data)'), controller: TextEditingController(text: espUrl), onChanged: (v)=>espUrl=v),
            ],
            SizedBox(height:8),
            Text('Creators', style: TextStyle(color: Colors.blueGrey)),
            Row(children: [ Image.asset('assets/logo.png', height:36), SizedBox(width:8), Text('Created by You') ])
          ],
        ),
      ),
    );
  }
}